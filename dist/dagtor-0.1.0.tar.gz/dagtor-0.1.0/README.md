# dagtor

A pet project to create simple orchestrator for a Directly Acyclic Graph (DAG) of arbitrary tasks

Supports:
 - asynchronous execution
 - external state in a persistent storage
 - pipeline of dependable tasks 
 - failure handling  